# BOD Backend - Minimal Spring Boot Skeleton

This is a minimal Spring Boot backend skeleton for the BOD (Board of Directors?) event/reservation system.
It includes:
- Spring Boot app (Java 17)
- PostgreSQL persistence (no SQLite)
- Redis configuration placeholder
- Basic entities: User, Event, Seat, Reservation
- ReservationService demonstrating reservation -> purchase flow (mock payment)
- Dockerfile and docker-compose for local demo

## Run locally (simple)
1. Build jar:
   ```bash
   mvn package
   ```
2. Start services with Docker Compose:
   ```bash
   docker-compose up --build
   ```
3. The app will be at `http://localhost:8080`.

## Endpoints (demo)
- `GET /api/events` - list events
- `POST /api/events/{eventId}/reserve?seatId={seatId}&userId={userId}` - reserve
- `POST /api/events/reservations/{id}/purchase` - mock purchase

This project is intentionally minimal to fit into a previewable zip. Expand services, security, QR generation, and payment integration as needed.
