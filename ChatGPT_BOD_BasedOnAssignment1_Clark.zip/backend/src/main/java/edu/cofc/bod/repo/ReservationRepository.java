package edu.cofc.bod.repo;

import edu.cofc.bod.model.Reservation;
import edu.cofc.bod.model.ReservationStatus;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ReservationRepository extends JpaRepository<Reservation, Long> {

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select r from Reservation r where r.seat.id = :seatId and r.event.id = :eventId and r.status in :active")
    Optional<Reservation> findActiveForSeat(@Param("seatId") Long seatId, @Param("eventId") Long eventId, @Param("active") List<ReservationStatus> active);
}
