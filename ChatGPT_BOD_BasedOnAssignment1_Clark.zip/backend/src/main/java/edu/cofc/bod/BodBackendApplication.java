package edu.cofc.bod;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BodBackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(BodBackendApplication.class, args);
    }
}
