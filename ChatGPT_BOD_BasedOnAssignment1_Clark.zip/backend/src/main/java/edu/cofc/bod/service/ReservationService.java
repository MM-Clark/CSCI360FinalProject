package edu.cofc.bod.service;

import edu.cofc.bod.model.*;
import edu.cofc.bod.repo.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ReservationService {
    private final ReservationRepository reservationRepo;
    private final SeatRepository seatRepo;
    private final EventRepository eventRepo;
    private final UserRepository userRepo;

    @Transactional
    public Reservation reserveSeat(Long userId, Long eventId, Long seatId) {
        var seat = seatRepo.findById(seatId).orElseThrow(() -> new IllegalArgumentException("seat not found"));
        var event = eventRepo.findById(eventId).orElseThrow(() -> new IllegalArgumentException("event not found"));
        var user = userRepo.findById(userId).orElseThrow(() -> new IllegalArgumentException("user not found"));

        var conflict = reservationRepo.findActiveForSeat(seatId, eventId, List.of(ReservationStatus.RESERVED, ReservationStatus.BOUGHT));
        if (conflict.isPresent()) {
            throw new IllegalStateException("Seat unavailable");
        }

        var res = Reservation.builder()
                .user(user)
                .event(event)
                .seat(seat)
                .status(ReservationStatus.RESERVED)
                .createdAt(Instant.now())
                .build();
        return reservationRepo.save(res);
    }

    @Transactional
    public Reservation purchaseReservation(Long reservationId) {
        var res = reservationRepo.findById(reservationId).orElseThrow(() -> new IllegalArgumentException("reservation not found"));
        if (res.getStatus() != ReservationStatus.RESERVED) throw new IllegalStateException("not reserved");
        // Mock payment success for demo
        res.setStatus(ReservationStatus.BOUGHT);
        res.setUpdatedAt(Instant.now());
        res.setQrCode("QR_MOCK_" + res.getId());
        return reservationRepo.save(res);
    }
}
