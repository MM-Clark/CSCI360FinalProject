package edu.cofc.bod.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

@Entity
@Table(name = "reservations")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Reservation {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(optional = false)
    private User user;
    @ManyToOne(optional = false)
    private Event event;
    @ManyToOne(optional = false)
    private Seat seat;
    @Enumerated(EnumType.STRING)
    private ReservationStatus status;
    @Column(length = 4000)
    private String qrCode;
    private Instant createdAt;
    private Instant updatedAt;
}
