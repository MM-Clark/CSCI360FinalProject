package edu.cofc.bod.controller;

import edu.cofc.bod.model.Event;
import edu.cofc.bod.model.Reservation;
import edu.cofc.bod.repo.EventRepository;
import edu.cofc.bod.service.ReservationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/events")
@RequiredArgsConstructor
public class EventController {
    private final EventRepository eventRepo;
    private final ReservationService reservationService;

    @GetMapping
    public List<Event> list() {
        return eventRepo.findAll();
    }

    @PostMapping("/{eventId}/reserve")
    public ResponseEntity<?> reserve(@PathVariable Long eventId, @RequestParam Long seatId, @RequestParam Long userId) {
        Reservation r = reservationService.reserveSeat(userId, eventId, seatId);
        return ResponseEntity.ok(r);
    }

    @PostMapping("/reservations/{id}/purchase")
    public ResponseEntity<?> purchase(@PathVariable Long id) {
        Reservation r = reservationService.purchaseReservation(id);
        return ResponseEntity.ok(r);
    }
}
