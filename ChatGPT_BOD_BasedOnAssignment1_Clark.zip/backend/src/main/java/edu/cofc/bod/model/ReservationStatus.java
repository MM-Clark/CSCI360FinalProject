package edu.cofc.bod.model;

public enum ReservationStatus {
    RESERVED,
    BOUGHT,
    CANCELLED,
    TRANSFER_PENDING,
    TRANSFERRED
}
