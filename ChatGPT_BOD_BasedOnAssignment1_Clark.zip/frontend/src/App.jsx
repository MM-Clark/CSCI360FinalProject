import React, { useEffect, useState } from "react";
import QRCode from "react-qr-code";

export default function App() {
  const [events, setEvents] = useState([]);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [seats, setSeats] = useState([]);
  const [selectedSeat, setSelectedSeat] = useState(null);
  const [reservation, setReservation] = useState(null);
  const [purchased, setPurchased] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Fetch events from backend
  useEffect(() => {
    fetch("http://localhost:8080/api/events")
      .then((res) => res.json())
      .then((data) => setEvents(data))
      .catch(() => setError("Could not load events."));
  }, []);

  const loadSeats = async (eventId) => {
    try {
      setSelectedEvent(eventId);
      setSeats([]);
      setSelectedSeat(null);
      const res = await fetch(`http://localhost:8080/api/events/${eventId}/seats`);
      if (!res.ok) throw new Error("Failed to load seats");
      const data = await res.json();
      setSeats(data);
    } catch (e) {
      setError(e.message);
    }
  };

  const handleReserve = async () => {
    if (!selectedEvent || !selectedSeat) return;
    try {
      setLoading(true);
      const res = await fetch(
        `http://localhost:8080/api/events/${selectedEvent}/reserve?seatId=${selectedSeat}&userId=1`,
        { method: "POST" }
      );
      if (!res.ok) throw new Error("Reservation failed");
      const data = await res.json();
      setReservation(data);
      setError(null);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  const handlePurchase = async (reservationId) => {
    try {
      setLoading(true);
      const res = await fetch(
        `http://localhost:8080/api/events/reservations/${reservationId}/purchase`,
        { method: "POST" }
      );
      if (!res.ok) throw new Error("Purchase failed");
      const data = await res.json();
      setPurchased(data);
      setError(null);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: 24, fontFamily: 'Inter, system-ui, -apple-system, "Segoe UI", Roboto' }}>
      <h1>🎟️ BOD Ticketing Demo</h1>

      {error && (<div style={{ color: 'crimson', margin: '12px 0' }}>{error}</div>)}

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 12 }}>
        {events.map((ev) => (
          <div key={ev.id} style={{ border: '1px solid #e5e7eb', borderRadius: 12, padding: 12 }}>
            <h3 style={{ margin: 0 }}>{ev.name}</h3>
            <p style={{ color: '#6b7280' }}>{ev.description}</p>
            <div style={{ fontSize: 12, color: '#9ca3af' }}>
              {new Date(ev.startTime).toLocaleString()} - {new Date(ev.endTime).toLocaleString()}
            </div>
            <button style={{ marginTop: 8 }} onClick={() => loadSeats(ev.id)}>View Seats</button>
          </div>
        ))}
      </div>

      {seats.length > 0 && (
        <div style={{ marginTop: 24, padding: 12, background: '#fff', borderRadius: 12 }}>
          <h3>Select a Seat</h3>
          <div style={{
            display: 'grid', gridTemplateColumns: 'repeat(8, 1fr)', gap: 8
          }}>
            {seats.map((seat) => (
              <button
                key={seat.id}
                onClick={() => setSelectedSeat(seat.id)}
                disabled={seat.reserved}
                style={{
                  padding: 8,
                  borderRadius: 6,
                  border: selectedSeat === seat.id ? '2px solid #2563eb' : '1px solid #e5e7eb',
                  background: seat.reserved ? '#f3f4f6' : '#fff',
                  cursor: seat.reserved ? 'not-allowed' : 'pointer'
                }}
              >
                {seat.row}-{seat.number}
              </button>
            ))}
          </div>
          <div style={{ marginTop: 12 }}>
            <button onClick={handleReserve} disabled={!selectedSeat || loading}>
              {loading ? 'Reserving...' : 'Reserve Selected Seat'}
            </button>
          </div>
        </div>
      )}

      {reservation && (
        <div style={{ marginTop: 24, padding: 12, background: '#fff', borderRadius: 12 }}>
          <h3>Reservation</h3>
          <pre style={{ background: '#f3f4f6', padding: 8 }}>{JSON.stringify(reservation, null, 2)}</pre>
          <button onClick={() => handlePurchase(reservation.id)} disabled={loading}>
            {loading ? 'Processing...' : 'Complete Purchase'}
          </button>
        </div>
      )}

      {purchased && (
        <div style={{ marginTop: 24, padding: 12, background: '#ecfdf5', borderRadius: 12 }}>
          <h3>Purchase Successful 🎉</h3>
          <div style={{ background: '#fff', padding: 12, display: 'inline-block', borderRadius: 8 }}>
            <QRCode value={purchased.qrCode || ""} size={128} />
          </div>
          <div style={{ marginTop: 8, color: '#6b7280' }}>QR Code Value: {purchased.qrCode}</div>
        </div>
      )}
    </div>
);
}
