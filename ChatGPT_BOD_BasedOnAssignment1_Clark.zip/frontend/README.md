# BOD Frontend (Demo)

This is a minimal React demo frontend that talks to the backend at http://localhost:8080.

Install:
  npm install

Run:
  npm start

The main app is at src/App.jsx
