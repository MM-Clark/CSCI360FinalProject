        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <h1 className="text-xl font-bold text-gray-800">Box Office Dragon</h1>
              <div className="flex space-x-1">
                {tabs.map(tab => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => {
                        setActiveTab(tab.id);
                        if (tab.id === 'events') {
                          setSelectedEvent(null);
                          setSelectedSeat(null);
                        }
                      }}
                      className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                        activeTab === tab.id 
                          ? 'bg-blue-100 text-blue-700' 
                          : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                      }`}
                    >
                      <Icon size={16} />
                      {tab.label}
                    </button>
                  );
                })}
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <User size={16} />
                <span>{currentUser.name} ({currentUser.role === 'buyer' ? 'CofC Community' : currentUser.role})</span>
              </div>
              <button
                onClick={() => setCurrentUser(null)}
                className="text-red-600 hover:text-red-800 text-sm"
              >
                Logout
              </button>
            </div>
          </div>
        </div> import React, { useState, useEffect } from 'react';
import { User, Calendar, MapPin, QrCode, Shield, Scan, CreditCard, Users, AlertCircle } from 'lucide-react';

// Mock data
const mockEvents = [
  {
    id: 1,
    name: 'Cougar Basketball vs Citadel',
    venue: 'TD Arena',
    date: '2024-11-25',
    time: '19:00',
    capacity: 5100,
    bookedSeats: 1122,
    description: 'CofC Cougars take on The Citadel Bulldogs in conference play',
    auditoriums: [
      {
        id: 1,
        name: 'Main Court',
        seats: Array.from({ length: 400 }, (_, i) => ({
          id: i + 1,
          row: Math.floor(i / 20) + 1,
          column: (i % 20) + 1,
          tier: i < 80 ? 'premium' : i < 240 ? 'standard' : 'economy',
          price: i < 80 ? 85 : i < 240 ? 45 : 25,
          isHandicap: i % 25 === 0,
          isFacultyOnly: i % 30 === 0 && i < 60,
          isBooked: Math.random() < 0.2
        }))
      }
    ]
  },
  {
    id: 2,
    name: 'Theatre: The Tempest',
    venue: 'Emmett Robinson Theatre',
    date: '2024-12-05',
    time: '19:30',
    capacity: 240,
    bookedSeats: 156,
    description: 'Shakespeare\'s final play performed by CofC Theatre students',
    auditoriums: [
      {
        id: 2,
        name: 'Main Theatre',
        seats: Array.from({ length: 240 }, (_, i) => ({
          id: i + 1,
          row: Math.floor(i / 15) + 1,
          column: (i % 15) + 1,
          tier: i < 45 ? 'premium' : i < 150 ? 'standard' : 'economy',
          price: i < 45 ? 35 : i < 150 ? 25 : 15,
          isHandicap: i % 20 === 0,
          isFacultyOnly: i % 25 === 0 && i < 45,
          isBooked: Math.random() < 0.65
        }))
      }
    ]
  },
  {
    id: 3,
    name: 'Jazz Ensemble Concert',
    venue: 'Recital Hall',
    date: '2024-11-30',
    time: '20:00',
    capacity: 150,
    bookedSeats: 67,
    description: 'CofC Jazz Ensemble presents an evening of contemporary and classic jazz',
    auditoriums: [
      {
        id: 3,
        name: 'Concert Hall',
        seats: Array.from({ length: 150 }, (_, i) => ({
          id: i + 1,
          row: Math.floor(i / 12) + 1,
          column: (i % 12) + 1,
          tier: i < 36 ? 'premium' : i < 96 ? 'standard' : 'economy',
          price: i < 36 ? 30 : i < 96 ? 20 : 12,
          isHandicap: i % 15 === 0,
          isFacultyOnly: i % 20 === 0 && i < 40,
          isBooked: Math.random() < 0.45
        }))
      }
    ]
  }
];

const TicketingSystem = () => {
  const [currentUser, setCurrentUser] = useState(null);
  const [activeTab, setActiveTab] = useState('events');
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [selectedSeat, setSelectedSeat] = useState(null);
  const [userTickets, setUserTickets] = useState([]);
  const [events, setEvents] = useState(mockEvents);

  // Login component
  const Login = () => {
    const [userType, setUserType] = useState('buyer');
    const [username, setUsername] = useState('');

    const handleLogin = () => {
      const user = {
        id: Math.random().toString(36).substr(2, 9),
        name: username || `${userType.charAt(0).toUpperCase() + userType.slice(1)} User`,
        role: userType,
        email: `${username || userType}@cofc.edu`,
        // Determine discount eligibility
        discount: userType === 'buyer' ? 0.1 : 0 // 10% discount for CofC community
      };
      setCurrentUser(user);
    };

    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-xl shadow-lg p-8 w-full max-w-md">
          <div className="text-center mb-6">
            <h1 className="text-3xl font-bold text-gray-800 mb-2">Box Office Dragon</h1>
            <p className="text-gray-600">CofC Event Ticketing</p>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">User Type</label>
              <select 
                value={userType} 
                onChange={(e) => setUserType(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="buyer">Buyer (Student/Faculty/Staff)</option>
                <option value="admin">Admin</option>
                <option value="enforcer">Ticket Enforcer</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Username/Email</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter your CofC email or username"
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            
            <button
              onClick={handleLogin}
              className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium"
            >
              Login
            </button>
          </div>
        </div>
      </div>
    );
  };

  // Event List Component
  const EventList = () => {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold text-gray-800">Available Events</h2>
          <div className="text-sm text-gray-600">
            {currentUser.role === 'buyer' && 'CofC Community - 10% Discount Applied'}
          </div>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {events.map(event => (
            <div key={event.id} className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow cursor-pointer"
                 onClick={() => setSelectedEvent(event)}>
              <h3 className="text-xl font-semibold text-gray-800 mb-2">{event.name}</h3>
              <div className="space-y-2 text-gray-600 text-sm mb-3">
                <div className="flex items-center gap-2">
                  <MapPin size={16} />
                  <span>{event.venue}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar size={16} />
                  <span>{event.date} at {event.time}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users size={16} />
                  <span>{Math.round((event.bookedSeats / event.capacity) * 100)}% full</span>
                </div>
              </div>
              {event.description && (
                <p className="text-gray-600 text-sm mb-3 line-clamp-2">{event.description}</p>
              )}
              <div className="mt-4">
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-blue-600 h-2 rounded-full" 
                       style={{width: `${(event.bookedSeats / event.capacity) * 100}%`}}></div>
                </div>
                <div className="mt-2 text-xs text-gray-500">
                  {event.bookedSeats} / {event.capacity} seats reserved
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  // Seat Selection Component
  const SeatSelection = () => {
    if (!selectedEvent) return <EventList />;

    const handleSeatSelect = (seat) => {
      if (seat.isBooked) return;
      
      // Check restrictions
      if (seat.isFacultyOnly && currentUser.role !== 'buyer') {
        alert('This seat is reserved for CofC community members only.');
        return;
      }
      
      setSelectedSeat(seat);
    };

    const getSeatColor = (seat) => {
      if (seat.isBooked) return 'bg-gray-400';
      if (seat.id === selectedSeat?.id) return 'bg-green-500';
      if (seat.tier === 'premium') return 'bg-yellow-400';
      if (seat.tier === 'standard') return 'bg-blue-400';
      if (seat.tier === 'economy') return 'bg-green-400';
      return 'bg-gray-300';
    };

    const getSeatBorder = (seat) => {
      if (seat.isHandicap) return 'border-2 border-purple-600';
      if (seat.isFacultyOnly) return 'border-2 border-red-600';
      return 'border border-gray-300';
    };

    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <button 
            onClick={() => setSelectedEvent(null)}
            className="text-blue-600 hover:text-blue-800"
          >
            ← Back to Events
          </button>
          <h2 className="text-2xl font-bold text-gray-800">{selectedEvent.name}</h2>
        </div>

        {selectedEvent.auditoriums.map(auditorium => (
          <div key={auditorium.id} className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold mb-4">{auditorium.name}</h3>
            
            {/* Legend */}
            <div className="mb-6 flex flex-wrap gap-4 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-yellow-400 border border-gray-300"></div>
                <span>Premium ($30-85)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-blue-400 border border-gray-300"></div>
                <span>Standard ($20-45)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-green-400 border border-gray-300"></div>
                <span>Economy ($12-25)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-gray-400 border border-gray-300"></div>
                <span>Booked</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-white border-2 border-purple-600"></div>
                <span>Handicap Accessible</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-white border-2 border-red-600"></div>
                <span>CofC Community Only</span>
              </div>
              {currentUser.role === 'buyer' && (
                <div className="text-green-600 font-medium">
                  🎓 CofC Discount Applied: 10% off
                </div>
              )}
            </div>

            {/* Seats Grid */}
            <div className="grid gap-1 justify-center seat-grid" style={{gridTemplateColumns: selectedEvent.capacity === 300 ? 'repeat(25, 1fr)' : selectedEvent.capacity === 150 ? 'repeat(15, 1fr)' : 'repeat(20, 1fr)'}}>
              {auditorium.seats.map(seat => (
                <button
                  key={seat.id}
                  onClick={() => handleSeatSelect(seat)}
                  disabled={seat.isBooked}
                  className={`w-6 h-6 text-xs font-medium rounded seat-button ${getSeatColor(seat)} ${getSeatBorder(seat)} 
                            hover:opacity-80 transition-opacity ${seat.isBooked ? 'cursor-not-allowed' : 'cursor-pointer'} ${seat.id === selectedSeat?.id ? 'seat-selected' : ''}`}
                  title={`Row ${seat.row}, Seat ${seat.column} - $${seat.price} ${seat.isHandicap ? '(Handicap)' : ''} ${seat.isFacultyOnly ? '(Faculty Only)' : ''}`}
                >
                  {seat.column}
                </button>
              ))}
            </div>

            {selectedSeat && (
              <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                <h4 className="font-semibold mb-2">Selected Seat</h4>
                <p>Row {selectedSeat.row}, Seat {selectedSeat.column}</p>
                <p>Original Price: ${selectedSeat.price}</p>
                {currentUser.role === 'buyer' && (
                  <p className="text-green-600">CofC Discount (10%): -${(selectedSeat.price * 0.1).toFixed(2)}</p>
                )}
                <p className="font-semibold">
                  Final Price: ${currentUser.role === 'buyer' ? 
                    (selectedSeat.price * 0.9).toFixed(2) : 
                    selectedSeat.price}
                </p>
                <p>Tier: {selectedSeat.tier}</p>
                {selectedSeat.isHandicap && <p className="text-purple-600">Handicap Accessible</p>}
                {selectedSeat.isFacultyOnly && <p className="text-red-600">CofC Community Only</p>}
                <button
                  onClick={() => bookSeat()}
                  className="mt-3 bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 transition-colors"
                >
                  Book Seat - ${currentUser.role === 'buyer' ? 
                    (selectedSeat.price * 0.9).toFixed(2) : 
                    selectedSeat.price}
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    );
  };

  // Book seat function
  const bookSeat = () => {
    if (!selectedSeat || !selectedEvent) return;

    const originalPrice = selectedSeat.price;
    const finalPrice = currentUser.role === 'buyer' ? originalPrice * 0.9 : originalPrice;

    const ticket = {
      id: Math.random().toString(36).substr(2, 9),
      eventId: selectedEvent.id,
      eventName: selectedEvent.name,
      venue: selectedEvent.venue,
      date: selectedEvent.date,
      time: selectedEvent.time,
      seatId: selectedSeat.id,
      row: selectedSeat.row,
      column: selectedSeat.column,
      originalPrice: originalPrice,
      finalPrice: finalPrice,
      discount: currentUser.role === 'buyer' ? 0.1 : 0,
      tier: selectedSeat.tier,
      qrCode: Math.random().toString(36).substr(2, 12).toUpperCase(),
      alternateId: Math.floor(Math.random() * 1000000),
      userId: currentUser.id,
      bookedAt: new Date().toISOString()
    };

    setUserTickets([...userTickets, ticket]);
    
    // Update seat as booked
    setEvents(prevEvents => 
      prevEvents.map(event => 
        event.id === selectedEvent.id 
          ? {
              ...event,
              bookedSeats: event.bookedSeats + 1,
              auditoriums: event.auditoriums.map(aud => ({
                ...aud,
                seats: aud.seats.map(seat => 
                  seat.id === selectedSeat.id ? {...seat, isBooked: true} : seat
                )
              }))
            }
          : event
      )
    );

    setSelectedSeat(null);
    alert('Ticket booked successfully! Confirmation email will be sent shortly.');
  };

  // My Tickets Component
  const MyTickets = () => {
    const returnTicket = (ticketId) => {
      const ticket = userTickets.find(t => t.id === ticketId);
      if (!ticket) return;

      // Update events to free the seat
      setEvents(prevEvents => 
        prevEvents.map(event => 
          event.id === ticket.eventId 
            ? {
                ...event,
                bookedSeats: event.bookedSeats - 1,
                auditoriums: event.auditoriums.map(aud => ({
                  ...aud,
                  seats: aud.seats.map(seat => 
                    seat.id === ticket.seatId ? {...seat, isBooked: false} : seat
                  )
                }))
              }
            : event
        )
      );

      setUserTickets(userTickets.filter(t => t.id !== ticketId));
      alert('Ticket returned successfully!');
    };

    return (
      <div className="space-y-4">
        <h2 className="text-2xl font-bold text-gray-800">My Tickets</h2>
        {userTickets.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            No tickets booked yet.
          </div>
        ) : (
          <div className="grid gap-4 md:grid-cols-2">
            {userTickets.map(ticket => (
              <div key={ticket.id} className="bg-white rounded-lg shadow-md p-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-2">{ticket.eventName}</h3>
                <div className="space-y-2 text-gray-600 mb-4">
                  <p><strong>Venue:</strong> {ticket.venue}</p>
                  <p><strong>Date:</strong> {ticket.date} at {ticket.time}</p>
                  <p><strong>Seat:</strong> Row {ticket.row}, Seat {ticket.column}</p>
                  <p><strong>Tier:</strong> {ticket.tier}</p>
                  {ticket.discount > 0 && (
                    <>
                      <p><strong>Original Price:</strong> ${ticket.originalPrice}</p>
                      <p className="text-green-600"><strong>CofC Discount (10%):</strong> -${(ticket.originalPrice * ticket.discount).toFixed(2)}</p>
                    </>
                  )}
                  <p><strong>Final Price:</strong> ${ticket.finalPrice}</p>
                </div>
                
                {/* QR Code Section */}
                <div className="bg-gray-50 p-4 rounded-lg mb-4 text-center qr-code-container">
                  <div className="bg-white p-4 inline-block rounded border-2 border-dashed border-gray-300">
                    <QrCode size={80} className="mx-auto mb-2" />
                    <p className="text-xs font-mono">{ticket.qrCode}</p>
                  </div>
                  <p className="text-sm text-gray-600 mt-2">Alternate ID: {ticket.alternateId}</p>
                </div>
                
                <button
                  onClick={() => returnTicket(ticket.id)}
                  className="w-full bg-red-600 text-white py-2 rounded hover:bg-red-700 transition-colors"
                >
                  Return Ticket
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  };

  // Ticket Verification Component (for enforcers)
  const TicketVerification = () => {
    const [scanInput, setScanInput] = useState('');
    const [verificationResult, setVerificationResult] = useState(null);
    const [selectedEventForCheck, setSelectedEventForCheck] = useState(null);

    const verifyTicket = () => {
      const ticket = userTickets.find(t => 
        t.qrCode === scanInput.toUpperCase() || 
        t.alternateId.toString() === scanInput
      );

      if (ticket) {
        setVerificationResult({
          valid: true,
          ticket: ticket,
          message: 'Valid ticket'
        });
      } else {
        setVerificationResult({
          valid: false,
          message: 'Invalid ticket or ticket not found'
        });
      }
    };

    return (
      <div className="space-y-6">
        <h2 className="text-2xl font-bold text-gray-800">Ticket Verification</h2>
        
        {/* QR Code Scanner */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-xl font-semibold mb-4">Scan Ticket</h3>
          <div className="space-y-4">
            <input
              type="text"
              value={scanInput}
              onChange={(e) => setScanInput(e.target.value)}
              placeholder="Enter QR code or Alternate ID"
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            <button
              onClick={verifyTicket}
              className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 transition-colors flex items-center gap-2"
            >
              <Scan size={16} />
              Verify Ticket
            </button>
          </div>

          {verificationResult && (
            <div className={`mt-4 p-4 rounded-lg ${verificationResult.valid ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'}`}>
              <div className={`flex items-center gap-2 ${verificationResult.valid ? 'text-green-800' : 'text-red-800'}`}>
                {verificationResult.valid ? (
                  <div className="w-4 h-4 bg-green-500 rounded-full"></div>
                ) : (
                  <AlertCircle size={16} />
                )}
                <span className="font-semibold">{verificationResult.message}</span>
              </div>
              
              {verificationResult.valid && verificationResult.ticket && (
                <div className="mt-3 text-gray-700">
                  <p><strong>Event:</strong> {verificationResult.ticket.eventName}</p>
                  <p><strong>Seat:</strong> Row {verificationResult.ticket.row}, Seat {verificationResult.ticket.column}</p>
                  <p><strong>Date:</strong> {verificationResult.ticket.date}</p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Event Capacity Check */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-xl font-semibold mb-4">Event Capacity Check</h3>
          <div className="space-y-4">
            <select
              value={selectedEventForCheck?.id || ''}
              onChange={(e) => setSelectedEventForCheck(events.find(ev => ev.id === parseInt(e.target.value)))}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Select an event</option>
              {events.map(event => (
                <option key={event.id} value={event.id}>{event.name}</option>
              )